# Client Technology
Deze repository bevat de setup code voor de colleges van Client Technology.

## Generated Code
De code van deze repository is gegenereerd.